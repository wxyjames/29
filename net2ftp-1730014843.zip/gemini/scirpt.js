// lah naghahanap ng source?

const typingForm = document.querySelector(".typing-form");
    const chatContainer = document.querySelector(".chat-list");

        typingForm.addEventListener("submit", async (e) => {
                const userMessage = typingForm.querySelector(".typing-input").value.trim();
                        if (!userMessage) return; 
                                
                                        appendMessage(userMessage, 'outgoing');
                                                typingForm.reset(); 

                                                        try {
                                                                    
                                                                                const response = await fetch('https//jimss.rf.gd/components/apis/gemapi.php', {
                                                                                                method: 'POST',
                                                                                                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                                                                                                                body: new URLSearchParams({ message: userMessage })
                                                                                                                                            });

                                                                                                                                                        const data = await response.json();
                                                                                                                                                                    if (data.error) throw new Error(data.error);

                                                                                                                                                                                const aiMessage = data.candidates[0].content.parts[0].text;
                                                                                                                                                                                            appendMessage(aiMessage, 'incoming');
                                                                                                                                                                                                    } catch (error) {
                                                                                                                                                                                                                appendMessage(`Error: ${error.message}`, 'error');
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                            });
                                                                                                                                                                                                                                const appendMessage = (message, type) => {
                                                                                                                                                                                                                                        const div = document.createElement("div");
                                                                                                                                                                                                                                                div.classList.add("message", type);
                                                                                                                                                                                                                                                        div.innerText = message;
                                                                                                                                                                                                                                                                chatContainer.appendChild(div);
                                                                                                                                                                                                                                                                        chatContainer.scrollTo(0, chatContainer.scrollHeight); 
                                                                                                                                                                                                                                                                            };

