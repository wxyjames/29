<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            <link rel="stylesheet" href="./style.css">
              <title>Gym Plan</title>
              </head>
              <body>
                <h1>
                   WORKOUT PLAN "BACK"
                     </h1>
                       <div class="container">
                           <textarea class="back" rows="21" cols="50" readonly>
                           *Back Workout (40-50 minutes)*

                           *Section 1: Lat Focus*

                           1. Pull-ups or Lat Pulldowns (3 sets of 8-12 reps)
                           2. Barbell Rows (3 sets of 8-12 reps)
                           3. Seated Cable Rows (3 sets of 10-15 reps)

                           *Section 2: Upper Back*

                           1. Deadlifts (3 sets of 8-12 reps)
                           2. Bent-Over Barbell Rows (3 sets of 8-12 reps)
                           3. Superman (3 sets of 10-15 reps)

                           *Section 3: Lower Back*

                           1. Romanian Deadlifts (3 sets of 8-12 reps)
                           2. Reverse Fly (3 sets of 10-15 reps)
                           3. Hyperextensions (3 sets of 10-15 reps)

                           *Cool-down (5-10 minutes)
                           
Back:
(As always go heavy but controlled)

T-Bar Rows
4 set 12-14 reps (add a little weight every set)

Single Arm Lat Pulldown
3 sets for each side 12-14 reps
(Make an extra Rep for the weaker Side) Make sure forms good and weighs controlled deep stretch and mind to muscle connection this is good asf

Dumbbell Bent Over Rows
(Alright with this one you want to have something supporting your forehead like an inclined bench)
3 sets 8-10 reps

And for finisher 
A Cable Lat Pulldown(any attachment but i like to use rope and straight bar)
1st-2nd set use Rope 10-14 reps
And for the 3rd(last set) use straight bar attachment 10-14 reps(push failure on this)

You can add face pulls if you still can or just chin ups
Just make it burn on face pulls(it means light weight)

So notes don't go Ego lifting on this one since you can't really make sure the weights are controlled properly and always use mind to muscle connection with that eccentric and concentric.
 </textarea>
                             </div>
                             </body>
                             </html>
                             