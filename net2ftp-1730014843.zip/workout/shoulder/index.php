<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            <link rel="stylesheet" href="./style.css">
              <title>Gym Plan</title>
              </head>
              <body>
                <h1>
                   WORKOUT PLAN "SHOULDER"
                     </h1>
                       <div class="container">
                           <textarea class="shoulder" rows="18" cols="50" readonly>
                           1. Overhead Barbell Press

                           Sets: 4

                           Reps: 8-10

                           Rest: 90 seconds


                           2. Dumbbell Lateral Raises

                           Sets: 3

                           Reps: 12-15

                           Rest: 60 seconds


                           3. Arnold Press

                           Sets: 3

                           Reps: 10-12

                           Rest: 60 seconds


                           4. Front Raises (Dumbbell or Plate)

                           Sets: 3

                           Reps: 10-12

                           Rest: 60 seconds


                           5. Face Pulls (with rope attachment)

                           Sets: 3

                           Reps: 12-15

                           Rest: 60 seconds


                           6. Dumbbell Shrugs

                           Sets: 3

                           Reps: 12-15

                           Rest: 60 seconds




                           </textarea>
                             </div>
                             </body>
                             </html>
                             