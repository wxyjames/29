<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            <title>Gym Plan</title>
              <link rel="stylesheet" href="./style.css">
              </head>
              <body>
                <h1>
                   WORKOUT PLAN "CHEST"
                     </h1>
                       <div class="container">
                           <textarea class="chest" rows="15" cols="50" readonly>
                           Heavy inclined dumbbell press 
                           4 set - 10-12 reps

                           Barbell inclined press (mas better kapag smith machine gamit)
                           3 set - 6-8 reps

                           Cable press(papuntang decline)
                           Set 2 - reps 12-14 reps
                           (1min rest)

                           Machine press 
                           1st-3rd set - 10-12 reps
                           4th set - 10-12 reps (make it more heavier)( absolute failure)</textarea>
                             </div>
                             </body>
                             </html>
                             