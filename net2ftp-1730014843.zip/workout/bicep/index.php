<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            <link rel="stylesheet" href="./style.css">
              <title>Gym Plan</title>
              </head>
              <body>
                <h1>
                   WORKOUT PLAN "BICEP"
                     </h1>
                       <div class="container">
                           <textarea class="bicep" rows="20" cols="50" readonly>

                           1. Barbell or EZ-Bar Curl

                           Sets: 4

                           Reps: 8-12

                           Rest: 90 seconds


                           2. Alternating Dumbbell Curls

                           Sets: 3

                           Reps: 10-12 per arm

                           Rest: 60 seconds


                           3. Hammer Curls

                           Sets: 3

                           Reps: 10-12

                           Rest: 60 seconds


                           4. Concentration Curls

                           Sets: 3

                           Reps: 10-12 per arm

                           Rest: 60 seconds


                           5. Preacher Curls (Machine or Dumbbell)

                           Sets: 3

                           Reps: 10-12

                           Rest: 60-90 seconds


                           6. Cable Curls (Rope or Bar Attachment)

                           Sets: 3

                           Reps: 12-15

                           Rest: 60 seconds


                           </textarea>
                             </div>
                             </body>
                             </html>
                             