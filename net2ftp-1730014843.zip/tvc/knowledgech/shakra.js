document.addEventListener("DOMContentLoaded", async () => {
        const video = document.getElementById('video');
            const player = new shaka.Player(video);

             
                 player.configure({
                       drm: {
                               clearKeys: {
                                         '0f856fa0412b11edb8780242ac120002': '783374273ef97ad3bc992c1d63e091e7'
                                                 }
                                                       }
                                                           });

                                                               
                                                                   player.addEventListener('error', onErrorEvent);

                                                                       try {
                                                                             
                                                                                   await player.load("https://qp-pldt-live-grp-13-prod.akamaized.net/out/u/dr_knowledgechannel.mpd");
                                                                                         console.log('playing a2z!');
                                                                                             } catch (error) {
                                                                                                   onError(error);
                                                                                                       }
                                                                                                         });

                                                                                                           function onErrorEvent(event) {
                                                                                                               onError(event.detail);
                                                                                                                 }

                                                                                                                   function onError(error) {
                                                                                                                       console.error('Error code', error.code, 'object', error);
                                                                                                                         }


