document.addEventListener("DOMContentLoaded", async () => {
        const video = document.getElementById('video');
            const player = new shaka.Player(video);

             
                 player.configure({
                       drm: {
                               clearKeys: {
                                         '322d06e9326f4753a7ec0908030c13d8': '1e3e0ca32d421fbfec86feced0efefda'
                                                 }
                                                       }
                                                           });

                                                               
                                                                   player.addEventListener('error', onErrorEvent);

                                                                       try {
                                                                             
                                                                                   await player.load("https://qp-pldt-live-grp-03-prod.akamaized.net/out/u/cg_onesportsplus_hd1.mpd");
                                                                                         console.log('playing a2z!');
                                                                                             } catch (error) {
                                                                                                   onError(error);
                                                                                                       }
                                                                                                         });

                                                                                                           function onErrorEvent(event) {
                                                                                                               onError(event.detail);
                                                                                                                 }

                                                                                                                   function onError(error) {
                                                                                                                       console.error('Error code', error.code, 'object', error);
                                                                                                                         }


