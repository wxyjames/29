<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Cinemo</title>
                <style>
                        body {
                                    display: flex;
                                                justify-content: center;
                                                            align-items: center;
                                                                        height: 100vh;
                                                                                    margin: 0;
                                                                                                background-color: black;
                                                                                                        }
                                                                                                                video {
                                                                                                                            max-width: 100%;
                                                                                                                                        height: auto;
                                                                                                                                                    
                                                                                                                                                                border-radius: 5px;
                                                                                                                                                                            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                                                                                                                                                                                    }
                                                                                                                                                                                        </style>
                                                                                                                                                                                        </head>
                                                                                                                                                                                        <body>
                                                                                                                                                                                            <video id="video" controls></video>

                                                                                                                                                                                                <script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
                                                                                                                                                                                                    <script src="luna.js"></script>
                                                                                                                                                                                                    </body>
                                                                                                                                                                                                    </html>