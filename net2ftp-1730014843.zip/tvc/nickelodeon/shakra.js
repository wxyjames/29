document.addEventListener("DOMContentLoaded", async () => {
        const video = document.getElementById('video');
            const player = new shaka.Player(video);

             
                 player.configure({
                       drm: {
                               clearKeys: {
                                         '9ce58f37576b416381b6514a809bfd8b': 'f0fbb758cdeeaddfa3eae538856b4d72'
                                                 }
                                                       }
                                                           });

                                                               
                                                                   player.addEventListener('error', onErrorEvent);

                                                                       try {
                                                                             
                                                                                   await player.load("https://qp-pldt-live-grp-11-prod.akamaized.net/out/u/dr_nickelodeon.mpd");
                                                                                         console.log('playing a2z!');
                                                                                             } catch (error) {
                                                                                                   onError(error);
                                                                                                       }
                                                                                                         });

                                                                                                           function onErrorEvent(event) {
                                                                                                               onError(event.detail);
                                                                                                                 }

                                                                                                                   function onError(error) {
                                                                                                                       console.error('Error code', error.code, 'object', error);
                                                                                                                         }


