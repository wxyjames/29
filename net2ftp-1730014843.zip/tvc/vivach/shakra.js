document.addEventListener("DOMContentLoaded", async () => {
        const video = document.getElementById('video');
            const player = new shaka.Player(video);

             
                 player.configure({
                       drm: {
                               clearKeys: {
                                         '07aa813bf2c147748046edd930f7736e': '3bd6688b8b44e96201e753224adfc8fb'
                                                 }
                                                       }
                                                           });

                                                               
                                                                   player.addEventListener('error', onErrorEvent);

                                                                       try {
                                                                             
                                                                                   await player.load("https://qp-pldt-live-grp-06-prod.akamaized.net/out/u/viva_sd.mpd");
                                                                                         console.log('playing a2z!');
                                                                                             } catch (error) {
                                                                                                   onError(error);
                                                                                                       }
                                                                                                         });

                                                                                                           function onErrorEvent(event) {
                                                                                                               onError(event.detail);
                                                                                                                 }

                                                                                                                   function onError(error) {
                                                                                                                       console.error('Error code', error.code, 'object', error);
                                                                                                                         }


