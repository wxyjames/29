document.addEventListener("DOMContentLoaded", async () => {
    const video = document.getElementById('video');
    const player = new shaka.Player(video);


    player.configure({
        drm: {
            clearKeys: {
                'a2d1f552ff9541558b3296b5a932136b': 'cdd48fa884dc0c3a3f85aeebca13d444'
            }
        }
    });


    player.addEventListener('error', onErrorEvent);

    try {

        await player.load("https://qp-pldt-live-grp-12-prod.akamaized.net/out/u/dr_cartoonnetworkhd.mpd");
        console.log('playing a2z!');
    } catch (error) {
        onError(error);
    }
});

function onErrorEvent(event) {
    onError(event.detail);
}

function onError(error) {
    console.error('Error code', error.code, 'object', error);
}


