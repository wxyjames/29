document.addEventListener("DOMContentLoaded", async () => {
        const video = document.getElementById('video');
            const player = new shaka.Player(video);

             
                 player.configure({
                       drm: {
                               clearKeys: {
                                         'd39eb201ae494a0b98583df4d110e8dd': '6797066880d344422abd3f5eda41f45f'
                                                 }
                                                       }
                                                           });

                                                               
                                                                   player.addEventListener('error', onErrorEvent);

                                                                       try {
                                                                             
                                                                                   await player.load("https://qp-pldt-live-grp-04-prod.akamaized.net/out/u/onenews_hd1.mpd");
                                                                                         console.log('playing a2z!');
                                                                                             } catch (error) {
                                                                                                   onError(error);
                                                                                                       }
                                                                                                         });

                                                                                                           function onErrorEvent(event) {
                                                                                                               onError(event.detail);
                                                                                                                 }

                                                                                                                   function onError(error) {
                                                                                                                       console.error('Error code', error.code, 'object', error);
                                                                                                                         }


