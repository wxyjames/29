<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
                    <link rel="stylesheet" href="luax.css">
                        <title>Priv</title>
                        </head>
                        <body>
                            <div class="container">
                                    <h1>FREE IPTV</h1>
                                              <p>enjoy watching!</p>
                                                      <div class="links">
                                                                    <a href="./myxph/" class="a1">🎥 MYX PH</a>

                                    <a href="./mtv/" class="a1">🎥 M TV</a>
                                                                         <a href="./tv5hd/" class="a1">🎥 TV5 HD</a>
                                                                             <a href="./a2z/" class="a1">🎥 A2Z</a>
                                                                                 <a href="./cinemaone/" class="a1">🎥 Cinema One</a>
                                                                                      <a href="./cinemo/" class="a1">🎥 Cinemo!</a>
                                                                                          <a href="./pbarush/" class="a1">🎥 PBA Rush</a>
                                                                                              <a href="./vivach/" class="a1">🎥 VIVA Channel</a>
                                                                                                  <a href="./onenews/" class="a1">🎥 One News</a>
                                                                                                      <a href="./oneph/" class="a1">🎥 ONE PH</a>
                                                                                                          <a href="./onesportsplus/" class="a1">🎥 One Sports+</a>
                                                                                                              <a href="./deped/" class="a1">🎥 Deped TV</a>
                                                                                                                 <a href="./knowledgech/" class="a1">🎥 Knowledge Channel</a>
                                                                                                                      <a href="./nickelodeon/" class="a1">🎥 Nickelodeon</a>
                                                                                                                          <a href="./nickjr/" class="a1">🎥 NickJR</a>
                                                                                                                              <a href="./animax/" class="a1">🎥 Animax</a>
                                                                                                                                   <a href="./cartoon-network/" class="a1">🎥 Cartoon Network</a>
                                                                                                                                       <a href="./disney/" class="a1">🎥 Disney Channel</a>
                                                                                                                                           <a href="./disneyxd/" class="a1">🎥 Disney XD</a>
                                                                                                                                               <a href="./dreamworks/" class="a1">🎥 DreamWorks</a>
                                                                                                                                                   <a href="./hbohd/" class="a1">🎥 HBO HD</a>
                                                                                                            <a href="./hbofam/" class="a1">🎥 HBO Family</a>
                                        <a href="./hbosign/"  class="a1">🎥 HBO Signature</a>                                                                                   
                                                                            <a href="./paramount/" class="a1">🎥 Paramount US</a>
                                
     <a href="./wbtv/" class="a1">🎥 WB TV</a>                                                                                                           <a href="./cinemax/" class="a1">🎥 Cinemax</a>
                                                                                                                                                           <a href="./kbsworld/" class="a1">🎥 KBS World</a>

                                                                        <a href="./kch/" class="a1">🎥 K Movies</a>
                                                                        <a href="./tvn/" class="a1">🎥 TVN Movies</a>
                                                                                                                                                              <a href="./premiersports/" class="a1">🎥 Premier Sports</a>
                                                                                                                                                                 
                                                                                                                                                                    
                                                                                                                                                                              </div>
                                                                                                                                                                                  </div>

                                                                                                                                                                                  </body>
                                                                                                                                                                                  </html>