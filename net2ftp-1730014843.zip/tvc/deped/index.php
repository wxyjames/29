<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Deped CH</title>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/shaka-player/4.0.0/shaka-player.compiled.min.js"></script>
          <style>
              body {
                    display: flex;
                          justify-content: center;
                                align-items: center;
                                      height: 100vh;
                                            margin: 0;
                                                  background-color: #000;
                                                      }
                                                          video {
                                                                max-width: 100%;
                                                                      height: auto;
                                                                          }
                                                                            </style>
                                                                            </head>
                                                                            <body>

                                                                            <video id="video" controls autoplay></video>

                                                                            <script src="shakra.js"></script>

                                                                            </body>
                                                                            </html>