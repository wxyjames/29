<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
        // Get the user's message from the POST request
            $userMessage = $_POST['message'];

                $api_key = 'AIzaSyB0WWckznsN-d56r8SLYtkl399IRUS9ng8';
                    $api_url = 'https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=' . $api_key;

                        // Prepare the data for the API request
                            $data = [
                                    'contents' => [
                                                [
                                                                'role' => 'user',
                                                                                'parts' => [
                                                                                                    ['text' => $userMessage]
                                                                                                                    ]
                                                                                                                                ]
                                                                                                                                        ]
                                                                                                                                            ];

                                                                                                                                                // Send the request to the API
                                                                                                                                                    $curl = curl_init($api_url);
                                                                                                                                                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                                                                                                                                                            curl_setopt($curl, CURLOPT_POST, true);
                                                                                                                                                                curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                                                                                                                                                                    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));

                                                                                                                                                                        $response = curl_exec($curl);
                                                                                                                                                                            if (curl_errno($curl)) {
                                                                                                                                                                                    echo json_encode(['error' => curl_error($curl)]);
                                                                                                                                                                                        } else {
                                                                                                                                                                                                echo $response;
                                                                                                                                                                                                    }

                                                                                                                                                                                                        curl_close($curl);
                                                                                                                                                                                                            exit;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            ?>